package com.codegnan.service;

import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.codegnan.dto.PatientDto;
import com.codegnan.entity.Patient;
import com.codegnan.exceptions.InvalidPatientIdException;
import com.codegnan.mapper.PatientMapper;
import com.codegnan.repo.PatientRepo;

@Service
public class PatientServiceImpl implements PatientService {

	private final PatientRepo patientRepo;
	private final PatientMapper patientMapper;
	private static Logger log = LoggerFactory.getLogger(PatientServiceImpl.class);

	public PatientServiceImpl(PatientRepo patientRepo, PatientMapper patientMapper) {
		super();
		this.patientRepo = patientRepo;
		this.patientMapper = patientMapper;
	}

	@Override
	@Transactional
	public PatientDto savePatient(PatientDto patientDto) {
		log.info("Registering New Patient");
		Patient patient=patientMapper.toEntity(patientDto);
		Patient saved=patientRepo.save(patient);
		log.debug("Patient Registered with Id : "+saved.getId());
		return patientMapper.toDto(saved);
	}

	@Override
	public PatientDto findByPatientById(Integer id) {
		log.info("Fetching Patient with Id : "+id);
		Patient p=patientRepo.findById(id).orElseThrow(()->{
			log.warn("Patient Not Found with Id : "+id);
			return new InvalidPatientIdException("Patient ID : "+id+" Not Found");
		});
		return patientMapper.toDto(p);
	}

	@Override
	public List<PatientDto> findAllPatients() {
		log.info("Fetching All Patients");
		List<PatientDto>list=patientRepo.findAll().stream().map(patientMapper::toDto).collect(Collectors.toList());
		log.debug("Total Patient Found : ",list.size());
		return list;
	}

	@Override
	@Transactional
	public PatientDto updatePatient(PatientDto pdo) {
		Integer id=pdo.getPatientId();
		log.info("Updating Patient with ID : "+id);
		Patient existing=patientRepo.findById(id).orElseThrow(()->{
			log.warn("Patient Not Found with Id : "+id+" to Update");
			return new InvalidPatientIdException("Patient ID : "+id+" Not Found");
		});
		
		existing.setAge(pdo.getPatientAge());
		existing.setName(pdo.getName());
		existing.setEmail(pdo.getEmailAddress());
		existing.setMobile(pdo.getPhone());
		existing.setGender(pdo.getGender());
		existing.setRegDate(pdo.getRegistrationDateStr());
		Patient updated=patientRepo.save(existing);
		log.debug("Patient Updated with Id : "+id);
		return patientMapper.toDto(updated);
	}

	@Override
	@Transactional
	public PatientDto deletePatient(Integer id) {
		log.info("Deleting Patient with ID : "+id);
		Patient existing=patientRepo.findById(id).orElseThrow(()->{
			log.warn("Patient Not Found with Id : "+id+" to Delete");
			return new InvalidPatientIdException("Patient ID : "+id+" Not Found");
		});
		patientRepo.delete(existing);
		return patientMapper.toDto(existing);
	}

}
