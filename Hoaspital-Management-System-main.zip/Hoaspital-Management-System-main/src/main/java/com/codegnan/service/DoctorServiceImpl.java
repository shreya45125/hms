package com.codegnan.service;

import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.codegnan.dto.DoctorDto;
import com.codegnan.entity.Doctor;
import com.codegnan.exceptions.InvalidDoctorIdException;
import com.codegnan.mapper.DoctorMapper;
import com.codegnan.repo.DoctorRepo;

@Service
public class DoctorServiceImpl implements DoctorService {

	private final DoctorRepo doctorRepo;
	private final DoctorMapper doctorMapper;
	private static Logger log = LoggerFactory.getLogger(DoctorServiceImpl.class);

	public DoctorServiceImpl(DoctorRepo doctorRepo, DoctorMapper doctorMapper) {
		super();
		this.doctorRepo = doctorRepo;
		this.doctorMapper = doctorMapper;
	}

	@Override
	@Transactional
	public DoctorDto hireDoctor(DoctorDto dto) {

		log.info("Hiring New Doctor");
		Doctor d = doctorMapper.toEntity(dto);
		Doctor saved = doctorRepo.save(d);
		log.debug("Doctor created with Id : ", saved.getId());
		return doctorMapper.toDto(saved);

	}

	@Override
	public DoctorDto findDoctorById(Integer id) {
		log.info("Fetching  Doctor with id :", id);
		Doctor d = doctorRepo.findById(id).orElseThrow(() -> {
			log.warn("Doctor Not Found with Id :", id);
			return new InvalidDoctorIdException("Doctor Id : " + id + " Not Found");
		});
		return doctorMapper.toDto(d);
	}

	@Override
	public List<DoctorDto> findAllDoctors() {
		log.info("Fetching All Doctors");
		List<DoctorDto> list = doctorRepo.findAll().stream().map(doctorMapper::toDto).collect(Collectors.toList());
		log.debug("Total doctors found : " + list.size());
		return list;
	}

	@Override
	@Transactional
	public DoctorDto updateDoctor(DoctorDto doctorDto) {
		Integer id = doctorDto.getDoctorId();
		log.info("Updating Doctor with id : ", id);

		Doctor existing = doctorRepo.findById(id).orElseThrow(() -> {
			log.warn("Doctor Not Found with Id :", id);
			return new InvalidDoctorIdException("Doctor Id : " + id + " Not Found");
		});

		existing.setName(doctorDto.getName());
		existing.setEmail(doctorDto.getEmailAddress());
		existing.setGender(doctorDto.getGender());
		existing.setMobile(doctorDto.getPhone());
		existing.setSpecialization(doctorDto.getFieldSpeciality());
		existing.setDegrees(doctorDto.getQualifications());
		existing.setSalary(doctorDto.getMonthlyPay());
		existing.setExperience(doctorDto.getYrsExperience());
		Doctor updated = doctorRepo.save(existing);
		log.debug("Doctor updated successdfully with Id " + updated.getId());
		return doctorMapper.toDto(updated);
	}

	@Override
	@Transactional
	public DoctorDto deleteDoctor(Integer id) {
		log.info("Deleting Doctor with id : ", id);

		Doctor existing = doctorRepo.findById(id).orElseThrow(() -> {
			log.warn("Doctor Not Found with Id :", id);
			return new InvalidDoctorIdException("Doctor Id : " + id + " Not Found");
		});
		doctorRepo.deleteById(id);
		log.debug("Doctor Deleted successfully with Id " + id);
		return doctorMapper.toDto(existing);
	}

}
