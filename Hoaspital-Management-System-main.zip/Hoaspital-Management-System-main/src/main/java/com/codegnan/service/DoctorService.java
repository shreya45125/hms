package com.codegnan.service;

import java.util.List;

import com.codegnan.dto.DoctorDto;

public interface DoctorService {
	
	public DoctorDto hireDoctor(DoctorDto dto);
	
	public DoctorDto findDoctorById(Integer id);
	
	public List<DoctorDto>findAllDoctors();
	
	public DoctorDto updateDoctor(DoctorDto doctorDto);
	
	public DoctorDto deleteDoctor(Integer id);

}
