package com.codegnan.service;

import java.util.List;

import com.codegnan.dto.VisitDto;

public interface VisitService {
	
	public VisitDto saveVisit(VisitDto vdo);
	
	public List<VisitDto> findVisits();
	
	public VisitDto findVisitById(Integer id);
	
	public VisitDto editVisit(VisitDto vdo);
	
	public VisitDto deleteVisit(Integer id);
	
	public List<VisitDto> findVisitsByPatientId(Integer id);
	
	public List<VisitDto> findVisitsByDoctorId(Integer did);

}
