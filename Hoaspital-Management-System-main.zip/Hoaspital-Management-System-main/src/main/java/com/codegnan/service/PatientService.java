package com.codegnan.service;

import java.util.List;

import com.codegnan.dto.PatientDto;

public interface PatientService {
	
	public PatientDto savePatient(PatientDto patientDto);
	
	public PatientDto findByPatientById(Integer id);
	
	public List<PatientDto>findAllPatients();
	
	public PatientDto updatePatient(PatientDto pdo);
	
	public PatientDto deletePatient(Integer id);

}
