package com.codegnan.exceptions;
public class InvalidVisitIdException extends RuntimeException {
	public InvalidVisitIdException(String message) {
		super(message);
	}
}
