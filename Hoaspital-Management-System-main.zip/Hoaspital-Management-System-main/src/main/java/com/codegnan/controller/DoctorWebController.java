package com.codegnan.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import com.codegnan.dto.DoctorDto;
import com.codegnan.service.DoctorService;
import java.util.List;

@Controller
@RequestMapping("/web/doctors")
public class DoctorWebController {

    private final DoctorService doctorService;

    public DoctorWebController(DoctorService doctorService) {
        this.doctorService = doctorService;
    }

    @GetMapping
    public String listDoctors(Model model) {
        List<DoctorDto> doctors = doctorService.findAllDoctors();
        model.addAttribute("doctors", doctors);
        return "doctors/list";
    }

    @GetMapping("/add")
    public String addDoctorForm(Model model) {
        model.addAttribute("doctor", new DoctorDto());
        return "doctors/form";
    }

    @PostMapping("/save")
    public String saveDoctor(@ModelAttribute("doctor") DoctorDto doctorDto) {
        if (doctorDto.getDoctorId() != null && doctorDto.getDoctorId() > 0) {
            doctorService.updateDoctor(doctorDto);
        } else {
            doctorService.hireDoctor(doctorDto);
        }
        return "redirect:/web/doctors";
    }

    @GetMapping("/edit/{id}")
    public String editDoctorForm(@PathVariable Integer id, Model model) {
        DoctorDto doctor = doctorService.findDoctorById(id);
        model.addAttribute("doctor", doctor);
        return "doctors/form";
    }

    @GetMapping("/delete/{id}")
    public String deleteDoctor(@PathVariable Integer id) {
        doctorService.deleteDoctor(id);
        return "redirect:/web/doctors";
    }
}
