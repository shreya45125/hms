package com.codegnan.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import com.codegnan.dto.PatientDto;
import com.codegnan.service.PatientService;
import java.util.List;

@Controller
@RequestMapping("/web/patients")
public class PatientWebController {

    private final PatientService patientService;

    public PatientWebController(PatientService patientService) {
        this.patientService = patientService;
    }

    @GetMapping
    public String listPatients(Model model) {
        List<PatientDto> patients = patientService.findAllPatients();
        model.addAttribute("patients", patients);
        return "patients/list";
    }

    @GetMapping("/add")
    public String addPatientForm(Model model) {
        model.addAttribute("patient", new PatientDto());
        return "patients/form";
    }

    @PostMapping("/save")
    public String savePatient(@ModelAttribute("patient") PatientDto patientDto) {
        // Simple mock implementation for ID check as IDs are usually auto-generated
        // Logic might need adjustment depending on how service handles updates vs
        // creates based on ID presence
        if (patientDto.getPatientId() != null && patientDto.getPatientId() > 0) {
            patientService.updatePatient(patientDto);
        } else {
            patientService.savePatient(patientDto);
        }
        return "redirect:/web/patients";
    }

    @GetMapping("/edit/{id}")
    public String editPatientForm(@PathVariable Integer id, Model model) {
        PatientDto patient = patientService.findByPatientById(id);
        model.addAttribute("patient", patient);
        return "patients/form";
    }

    @GetMapping("/delete/{id}")
    public String deletePatient(@PathVariable Integer id) {
        patientService.deletePatient(id);
        return "redirect:/web/patients";
    }
}
