package com.codegnan.controller;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.codegnan.dto.DoctorDto;
import com.codegnan.dto.VisitDto;
import com.codegnan.exceptions.InvalidDoctorIdException;
import com.codegnan.service.DoctorService;
import com.codegnan.service.VisitService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/doctors")
public class DoctorController {

	private static final Logger log = LoggerFactory.getLogger(DoctorController.class);

	private final DoctorService doctorService;
	private final VisitService visitService;

	public DoctorController(DoctorService doctorService, VisitService visitService) {
		super();
		this.doctorService = doctorService;
		this.visitService = visitService;
	}

	@GetMapping
	public List<DoctorDto> getAllDoctors() {
		log.info("GET/doctors");
		return doctorService.findAllDoctors();
	}

	@GetMapping("/{id}")
	public DoctorDto getDoctorById(@PathVariable Integer id) {
		log.info("GET/doctors/{}", id);
		return doctorService.findDoctorById(id);
	}

	@PostMapping
	public ResponseEntity<DoctorDto> createDoctor(@Valid @RequestBody DoctorDto doctorDto) {
		log.info("POST/doctors");
		DoctorDto d = doctorService.hireDoctor(doctorDto);
		log.debug("Doctor created with id ", d.getDoctorId());
		return ResponseEntity.status(HttpStatus.CREATED).body(d);
	}

	@PutMapping("/{id}")
	public DoctorDto updateDoctor(@PathVariable Integer id, @Valid @RequestBody DoctorDto dto) {
		log.info("PUT/doctors/{}", id);
		if (dto.getDoctorId() == null || !id.equals(dto.getDoctorId())) {
			log.warn("Doctor Id mismatch: path={},body={}", id, dto.getDoctorId());
			throw new InvalidDoctorIdException("Doctor Id in path and body must Match");

		}
		return doctorService.updateDoctor(dto);
	}

	@DeleteMapping("/{id}")
	public DoctorDto deleteDoctor(@PathVariable Integer id) {
		log.info("Delete/doctors/{} " + id);
		return doctorService.deleteDoctor(id);
	}

	@GetMapping("/{id}/visits")
	public List<VisitDto> getVisitsByDoctor(@PathVariable Integer id) {
		log.info("Get/doctors/{}/visits", id);
		return visitService.findVisitsByDoctorId(id);
	}

}
