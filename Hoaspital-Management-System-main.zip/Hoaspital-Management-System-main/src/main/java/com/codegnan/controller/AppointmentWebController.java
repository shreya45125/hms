package com.codegnan.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import com.codegnan.dto.VisitDto;
import com.codegnan.dto.DoctorDto;
import com.codegnan.dto.PatientDto;
import com.codegnan.service.VisitService;
import com.codegnan.service.DoctorService;
import com.codegnan.service.PatientService;
import java.util.List;

@Controller
@RequestMapping("/web/appointments")
public class AppointmentWebController {

    private final VisitService visitService;
    private final DoctorService doctorService;
    private final PatientService patientService;

    public AppointmentWebController(VisitService visitService, DoctorService doctorService,
            PatientService patientService) {
        this.visitService = visitService;
        this.doctorService = doctorService;
        this.patientService = patientService;
    }

    @GetMapping
    public String listAppointments(Model model) {
        List<VisitDto> visits = visitService.findVisits();
        model.addAttribute("visits", visits);
        return "appointments/list";
    }

    @GetMapping("/add")
    public String addAppointmentForm(Model model) {
        model.addAttribute("visit", new VisitDto());

        List<DoctorDto> doctors = doctorService.findAllDoctors();
        List<PatientDto> patients = patientService.findAllPatients();

        model.addAttribute("doctors", doctors);
        model.addAttribute("patients", patients);

        return "appointments/form";
    }

    @PostMapping("/save")
    public String saveAppointment(@ModelAttribute("visit") VisitDto visitDto) {
        if (visitDto.getVisitRef() != null && visitDto.getVisitRef() > 0) {
            visitService.editVisit(visitDto);
        } else {
            visitService.saveVisit(visitDto);
        }
        return "redirect:/web/appointments";
    }

    @GetMapping("/edit/{id}")
    public String editAppointmentForm(@PathVariable Integer id, Model model) {
        VisitDto visit = visitService.findVisitById(id);
        model.addAttribute("visit", visit);

        List<DoctorDto> doctors = doctorService.findAllDoctors();
        List<PatientDto> patients = patientService.findAllPatients();

        model.addAttribute("doctors", doctors);
        model.addAttribute("patients", patients);

        return "appointments/form";
    }

    @GetMapping("/delete/{id}")
    public String deleteAppointment(@PathVariable Integer id) {
        visitService.deleteVisit(id);
        return "redirect:/web/appointments";
    }
}
